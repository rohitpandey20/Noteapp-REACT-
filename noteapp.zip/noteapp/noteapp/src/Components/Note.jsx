import React from 'react';

const Note = ({ id, text }) => {
  return (
    <div className='note'>
      <div className='note-body'>{text}</div>
      <div className='note-footer' style={{ justifyContent: 'flex-end' }}>
        <button className='note_save'>Delete</button> &nbsp;
        <button className='note_save'>Edit</button>
      </div>
    </div>
  );
};

export default Note;
